#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Int32.h"
#include "framework/IntStr.h"
#include "framework/StrInt.h"

int setUpID(ros::NodeHandle& n){
    ros::ServiceClient client = n.serviceClient<framework::StrInt>("get_ROS_ID");
    framework::StrInt getID;
    getID.request.data = "EMOJI";

    while(!client.call(getID)){ros::spinOnce();}
    return getID.response.data;
}

int main(int argc, char** argv){
    ros::init(argc, argv, "emoji_gcs");
    ros::NodeHandle n("s");
    ros::Rate loop_rate(1);

    framework::IntStr id;
    id.request.ID = setUpID(n);

    ros::ServiceClient client = n.serviceClient<framework::IntStr>("req_ROS_Data");

    while (ros::ok()){
        ros::spinOnce();
        loop_rate.sleep();
    }
}
