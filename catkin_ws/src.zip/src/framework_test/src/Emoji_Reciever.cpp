#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Int32.h"
#include "framework/IntStr.h"
#include "framework/StrInt.h"

int setUpID(ros::NodeHandle& n){
    ros::ServiceClient client = n.serviceClient<framework::StrInt>("get_ROS_ID");
    framework::StrInt getID;
    getID.request.data = "EMOJI";

    while(!client.call(getID)){ros::spinOnce();}
    return getID.response.data;
}

int main(int argc, char** argv){
    ros::init(argc, argv, "emoji_bin");
    ros::NodeHandle n("s");

    framework::IntStr id;
    id.request.ID = setUpID(n);

}
